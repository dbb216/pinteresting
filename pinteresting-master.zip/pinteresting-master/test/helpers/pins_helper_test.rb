require 'test_helper'

class PinsHelperTest < ActionView::TestCase
end
