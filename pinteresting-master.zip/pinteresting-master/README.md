# One Month Rails

This is the pinteresting sample application for 
dbb216

by dbb216

